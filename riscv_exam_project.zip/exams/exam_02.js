window.registerExam({
  "id": "exam_02",
  "title": "Đề luyện tập 02 - RISC-V, Cache và Pipeline",
  "description": "Đề luyện tập 02. Mỗi câu 10 điểm, tổng 100 điểm.",
  "questions": [
    {
      "id": "q1",
      "type": "fields",
      "points": 10,
      "title": "Câu 1 - 2-way set associative cache, byte addressing",
      "prompt": "Here is the cache with the following key characteristics:<br><b>2-Way Set Associative Cache</b><br>Write policy: <b>Write-back using write allocate</b> (one Dirty bit for a block)<br>Block size is <b>32 bytes</b><br>Cache size is <b>64 KB</b><br>Memory is byte addressing with <b>32-bit addresses</b>.<br><br>Fill in the following values.",
      "fields": [
        {
          "id": "q1_index",
          "label": "Set index",
          "answers": [
            "10"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "10"
        },
        {
          "id": "q1_offset",
          "label": "Block offset",
          "answers": [
            "5"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "5"
        },
        {
          "id": "q1_tag",
          "label": "Tag size for a block",
          "answers": [
            "17"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "17"
        },
        {
          "id": "q1_blocks",
          "label": "Number of blocks",
          "answers": [
            "2048"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "2048"
        },
        {
          "id": "q1_bits",
          "label": "Total bits required to implement the cache",
          "answers": [
            "563200"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "563200"
        }
      ],
      "solution": "Blocks = 64KB / 32B = 2048. Sets = 2048 / 2 = 1024 => set index = 10 bits. Offset = log2(32) = 5 bits. Tag = 32 - 10 - 5 = 17 bits. Total bits = 2048 × (32×8 data + 17 tag + 1 valid + 1 dirty) = 563,200 bits."
    },
    {
      "id": "q2",
      "type": "fields",
      "points": 10,
      "title": "Câu 2 - 4-way set associative cache, byte addressing",
      "prompt": "Here is the cache with the following key characteristics:<br><b>4-Way Set Associative Cache</b><br>Write policy: <b>Write-back using write allocate</b> (one Dirty bit for a block)<br>Block size is <b>64 bytes</b><br>Cache size is <b>32 KB</b><br>Memory is byte addressing with <b>32-bit addresses</b>.",
      "fields": [
        {
          "id": "q2_index",
          "label": "Set index",
          "answers": [
            "7"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "7"
        },
        {
          "id": "q2_offset",
          "label": "Block offset",
          "answers": [
            "6"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "6"
        },
        {
          "id": "q2_tag",
          "label": "Tag size for a block",
          "answers": [
            "19"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "19"
        },
        {
          "id": "q2_blocks",
          "label": "Number of blocks",
          "answers": [
            "512"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "512"
        },
        {
          "id": "q2_bits",
          "label": "Total bits required to implement the cache",
          "answers": [
            "272896"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "272896"
        }
      ],
      "solution": "Blocks = 32KB / 64B = 512. Sets = 512 / 4 = 128 => index = 7 bits. Offset = 6 bits. Tag = 32 - 7 - 6 = 19 bits. Total = 512 × (64×8 + 19 + valid 1 + dirty 1) = 272,896 bits."
    },
    {
      "id": "q3",
      "type": "fields",
      "points": 10,
      "title": "Câu 3 - Fully associative cache parameters",
      "prompt": "Assume the main memory is <b>word addressing</b> with <b>8-bit addresses</b> and the cache is a <b>fully associative cache</b> with <b>two-word blocks</b> and a total size of <b>8 words</b>. Assume one word is <b>32 bits</b>.",
      "fields": [
        {
          "id": "q3_blocks_cache",
          "label": "Number of blocks in the cache",
          "answers": [
            "4"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "4"
        },
        {
          "id": "q3_sets",
          "label": "Number of sets in the cache",
          "answers": [
            "1"
          ],
          "type": "decimal",
          "unit": "sets",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q3_blocks_mem",
          "label": "Number of blocks in the memory",
          "answers": [
            "128"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "128"
        },
        {
          "id": "q3_tag",
          "label": "Number of tag bits in each block",
          "answers": [
            "7"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "7"
        },
        {
          "id": "q3_bits",
          "label": "Total bits required to implement the cache",
          "answers": [
            "288"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "288"
        }
      ],
      "solution": "Cache blocks = 8/2 = 4. Fully associative => 1 set and 0 index bits. Memory blocks = 2^8/2 = 128. Offset = log2(2) = 1 bit, so tag = 8 - 1 = 7 bits. Total = 4 × (2×32 data + 7 tag + 1 valid) = 288 bits."
    },
    {
      "id": "q4",
      "type": "access_table",
      "points": 10,
      "title": "Câu 4 - Fully associative cache với true LRU",
      "prompt": "Assume the main memory is <b>word addressing</b> with <b>8-bit addresses</b> and the cache is a <b>fully associative cache</b> with <b>two-word blocks</b> and a total size of <b>8 words</b>. Assume one word is <b>32 bits</b>.<br><br>Sequence of word addresses:<br><code>0x03, 0x04, 0x10, 0x20, 0x03, 0x24, 0x05, 0x21, 0x30, 0x04, 0x25, 0x31, 0x40, 0x03</code><br><br>Assume a true LRU replacement policy. For each reference, identify the binary word address, the tag, and hit/miss.",
      "columns": [
        "Word Address in Hex",
        "Word Address in Binary",
        "Tag in Binary",
        "Hit or Miss"
      ],
      "rows": [
        {
          "addr": "0x03",
          "cells": [
            {
              "id": "q4_0_bin",
              "label": "Word address in binary",
              "answers": [
                "00000011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000011"
            },
            {
              "id": "q4_0_tag",
              "label": "Tag in binary",
              "answers": [
                "0000001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000001"
            },
            {
              "id": "q4_0_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x04",
          "cells": [
            {
              "id": "q4_1_bin",
              "label": "Word address in binary",
              "answers": [
                "00000100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000100"
            },
            {
              "id": "q4_1_tag",
              "label": "Tag in binary",
              "answers": [
                "0000010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000010"
            },
            {
              "id": "q4_1_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x10",
          "cells": [
            {
              "id": "q4_2_bin",
              "label": "Word address in binary",
              "answers": [
                "00010000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00010000"
            },
            {
              "id": "q4_2_tag",
              "label": "Tag in binary",
              "answers": [
                "0001000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0001000"
            },
            {
              "id": "q4_2_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x20",
          "cells": [
            {
              "id": "q4_3_bin",
              "label": "Word address in binary",
              "answers": [
                "00100000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00100000"
            },
            {
              "id": "q4_3_tag",
              "label": "Tag in binary",
              "answers": [
                "0010000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010000"
            },
            {
              "id": "q4_3_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x03",
          "cells": [
            {
              "id": "q4_4_bin",
              "label": "Word address in binary",
              "answers": [
                "00000011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000011"
            },
            {
              "id": "q4_4_tag",
              "label": "Tag in binary",
              "answers": [
                "0000001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000001"
            },
            {
              "id": "q4_4_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            }
          ]
        },
        {
          "addr": "0x24",
          "cells": [
            {
              "id": "q4_5_bin",
              "label": "Word address in binary",
              "answers": [
                "00100100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00100100"
            },
            {
              "id": "q4_5_tag",
              "label": "Tag in binary",
              "answers": [
                "0010010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010010"
            },
            {
              "id": "q4_5_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x05",
          "cells": [
            {
              "id": "q4_6_bin",
              "label": "Word address in binary",
              "answers": [
                "00000101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000101"
            },
            {
              "id": "q4_6_tag",
              "label": "Tag in binary",
              "answers": [
                "0000010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000010"
            },
            {
              "id": "q4_6_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x21",
          "cells": [
            {
              "id": "q4_7_bin",
              "label": "Word address in binary",
              "answers": [
                "00100001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00100001"
            },
            {
              "id": "q4_7_tag",
              "label": "Tag in binary",
              "answers": [
                "0010000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010000"
            },
            {
              "id": "q4_7_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            }
          ]
        },
        {
          "addr": "0x30",
          "cells": [
            {
              "id": "q4_8_bin",
              "label": "Word address in binary",
              "answers": [
                "00110000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00110000"
            },
            {
              "id": "q4_8_tag",
              "label": "Tag in binary",
              "answers": [
                "0011000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0011000"
            },
            {
              "id": "q4_8_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x04",
          "cells": [
            {
              "id": "q4_9_bin",
              "label": "Word address in binary",
              "answers": [
                "00000100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000100"
            },
            {
              "id": "q4_9_tag",
              "label": "Tag in binary",
              "answers": [
                "0000010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000010"
            },
            {
              "id": "q4_9_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            }
          ]
        },
        {
          "addr": "0x25",
          "cells": [
            {
              "id": "q4_10_bin",
              "label": "Word address in binary",
              "answers": [
                "00100101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00100101"
            },
            {
              "id": "q4_10_tag",
              "label": "Tag in binary",
              "answers": [
                "0010010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010010"
            },
            {
              "id": "q4_10_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            }
          ]
        },
        {
          "addr": "0x31",
          "cells": [
            {
              "id": "q4_11_bin",
              "label": "Word address in binary",
              "answers": [
                "00110001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00110001"
            },
            {
              "id": "q4_11_tag",
              "label": "Tag in binary",
              "answers": [
                "0011000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0011000"
            },
            {
              "id": "q4_11_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            }
          ]
        },
        {
          "addr": "0x40",
          "cells": [
            {
              "id": "q4_12_bin",
              "label": "Word address in binary",
              "answers": [
                "01000000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "01000000"
            },
            {
              "id": "q4_12_tag",
              "label": "Tag in binary",
              "answers": [
                "0100000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0100000"
            },
            {
              "id": "q4_12_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        },
        {
          "addr": "0x03",
          "cells": [
            {
              "id": "q4_13_bin",
              "label": "Word address in binary",
              "answers": [
                "00000011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000011"
            },
            {
              "id": "q4_13_tag",
              "label": "Tag in binary",
              "answers": [
                "0000001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000001"
            },
            {
              "id": "q4_13_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            }
          ]
        }
      ],
      "fields_extra": [
        {
          "id": "q4_full",
          "label": "After these accesses, is the cache full?",
          "answers": [
            "yes",
            "y",
            "có",
            "co"
          ],
          "type": "text",
          "unit": "",
          "hint": "",
          "show": "yes"
        },
        {
          "id": "q4_repl",
          "label": "How many replacements occurred?",
          "answers": [
            "5"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "5"
        }
      ],
      "solution": "Block size = 2 words, so the last bit is offset and tag = address >> 1. The cache holds 4 blocks. Hit/miss sequence: M, M, M, M, H, M, M, H, M, H, H, H, M, M. The cache is full and there are 5 replacements."
    },
    {
      "id": "q5",
      "type": "access_table",
      "points": 10,
      "title": "Câu 5 - 3-way set associative cache, điền Way theo từng dòng",
      "prompt": "Assume the memory is <b>word addressing</b> with <b>8-bit addresses</b> and the cache is a <b>3-way set associative cache</b> with <b>2-word blocks</b> and a total size of <b>48 words</b>. Assume <b>1 word = 64 bits</b>.<br><br>First, fill in the cache parameters. Then use true LRU. For each reference, identify binary address, tag, set index, offset, hit/miss, and the tags in each way after the reference has been handled.<br><br><b>Lưu ý:</b> Nếu một Way có nhiều dòng như <code>T(index)=tag</code>, <code>T(xxx)=yyyy</code>, mỗi dòng sẽ là một ô nhập riêng. Các dòng trong Way nên xếp theo set index tăng dần.",
      "fields_intro": [
        {
          "id": "q5_cache_blocks",
          "label": "Number of blocks in the cache",
          "answers": [
            "24"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "24"
        },
        {
          "id": "q5_sets",
          "label": "Number of sets in the cache",
          "answers": [
            "8"
          ],
          "type": "decimal",
          "unit": "sets",
          "hint": "",
          "show": "8"
        },
        {
          "id": "q5_mem_blocks",
          "label": "Number of blocks in the memory",
          "answers": [
            "128"
          ],
          "type": "decimal",
          "unit": "blocks",
          "hint": "",
          "show": "128"
        },
        {
          "id": "q5_tag_bits",
          "label": "Number of tag bits in each block",
          "answers": [
            "4"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "4"
        },
        {
          "id": "q5_total_bits",
          "label": "Total bits required to implement the cache",
          "answers": [
            "3192"
          ],
          "type": "decimal",
          "unit": "bits",
          "hint": "",
          "show": "3192"
        }
      ],
      "columns": [
        "Word Address in Hex",
        "Word Address in Binary",
        "Tag in Binary",
        "Set Index in Binary",
        "Offset in Binary",
        "Hit or Miss",
        "Way 0",
        "Way 1",
        "Way 2"
      ],
      "rows": [
        {
          "addr": "0x03",
          "cells": [
            {
              "id": "q5_0_bin",
              "label": "Word address in binary",
              "answers": [
                "00000011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000011"
            },
            {
              "id": "q5_0_tag",
              "label": "Tag in binary",
              "answers": [
                "0000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000"
            },
            {
              "id": "q5_0_idx",
              "label": "Set index in binary",
              "answers": [
                "001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "001"
            },
            {
              "id": "q5_0_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_0_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r0_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0xb4",
          "cells": [
            {
              "id": "q5_1_bin",
              "label": "Word address in binary",
              "answers": [
                "10110100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10110100"
            },
            {
              "id": "q5_1_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_1_idx",
              "label": "Set index in binary",
              "answers": [
                "010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "010"
            },
            {
              "id": "q5_1_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_1_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r1_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r1_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0x2b",
          "cells": [
            {
              "id": "q5_2_bin",
              "label": "Word address in binary",
              "answers": [
                "00101011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00101011"
            },
            {
              "id": "q5_2_tag",
              "label": "Tag in binary",
              "answers": [
                "0010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010"
            },
            {
              "id": "q5_2_idx",
              "label": "Set index in binary",
              "answers": [
                "101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "101"
            },
            {
              "id": "q5_2_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_2_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r2_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r2_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r2_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0x02",
          "cells": [
            {
              "id": "q5_3_bin",
              "label": "Word address in binary",
              "answers": [
                "00000010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00000010"
            },
            {
              "id": "q5_3_tag",
              "label": "Tag in binary",
              "answers": [
                "0000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000"
            },
            {
              "id": "q5_3_idx",
              "label": "Set index in binary",
              "answers": [
                "001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "001"
            },
            {
              "id": "q5_3_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_3_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            },
            [
              {
                "id": "q5_r3_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r3_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r3_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0xbe",
          "cells": [
            {
              "id": "q5_4_bin",
              "label": "Word address in binary",
              "answers": [
                "10111110"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10111110"
            },
            {
              "id": "q5_4_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_4_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_4_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_4_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r4_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r4_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r4_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r4_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0x58",
          "cells": [
            {
              "id": "q5_5_bin",
              "label": "Word address in binary",
              "answers": [
                "01011000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "01011000"
            },
            {
              "id": "q5_5_tag",
              "label": "Tag in binary",
              "answers": [
                "0101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0101"
            },
            {
              "id": "q5_5_idx",
              "label": "Set index in binary",
              "answers": [
                "100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "100"
            },
            {
              "id": "q5_5_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_5_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r5_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r5_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r5_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r5_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r5_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0xbf",
          "cells": [
            {
              "id": "q5_6_bin",
              "label": "Word address in binary",
              "answers": [
                "10111111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10111111"
            },
            {
              "id": "q5_6_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_6_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_6_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_6_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            },
            [
              {
                "id": "q5_r6_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r6_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r6_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r6_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r6_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [],
            []
          ]
        },
        {
          "addr": "0x0e",
          "cells": [
            {
              "id": "q5_7_bin",
              "label": "Word address in binary",
              "answers": [
                "00001110"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00001110"
            },
            {
              "id": "q5_7_tag",
              "label": "Tag in binary",
              "answers": [
                "0000"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0000"
            },
            {
              "id": "q5_7_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_7_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_7_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r7_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r7_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r7_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r7_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r7_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r7_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0000"
              }
            ],
            []
          ]
        },
        {
          "addr": "0x1f",
          "cells": [
            {
              "id": "q5_8_bin",
              "label": "Word address in binary",
              "answers": [
                "00011111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00011111"
            },
            {
              "id": "q5_8_tag",
              "label": "Tag in binary",
              "answers": [
                "0001"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0001"
            },
            {
              "id": "q5_8_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_8_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_8_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r8_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r8_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r8_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r8_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r8_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r8_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0000"
              }
            ],
            [
              {
                "id": "q5_r8_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=0001"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0001"
              }
            ]
          ]
        },
        {
          "addr": "0xb5",
          "cells": [
            {
              "id": "q5_9_bin",
              "label": "Word address in binary",
              "answers": [
                "10110101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10110101"
            },
            {
              "id": "q5_9_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_9_idx",
              "label": "Set index in binary",
              "answers": [
                "010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "010"
            },
            {
              "id": "q5_9_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_9_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            },
            [
              {
                "id": "q5_r9_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r9_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r9_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r9_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r9_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r9_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0000"
              }
            ],
            [
              {
                "id": "q5_r9_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=0001"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0001"
              }
            ]
          ]
        },
        {
          "addr": "0xbf",
          "cells": [
            {
              "id": "q5_10_bin",
              "label": "Word address in binary",
              "answers": [
                "10111111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10111111"
            },
            {
              "id": "q5_10_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_10_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_10_off",
              "label": "Offset in binary",
              "answers": [
                "1"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1"
            },
            {
              "id": "q5_10_hm",
              "label": "Hit or Miss",
              "answers": [
                "H",
                "hit"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "H"
            },
            [
              {
                "id": "q5_r10_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r10_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r10_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r10_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r10_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r10_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0000"
              }
            ],
            [
              {
                "id": "q5_r10_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=0001"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0001"
              }
            ]
          ]
        },
        {
          "addr": "0xba",
          "cells": [
            {
              "id": "q5_11_bin",
              "label": "Word address in binary",
              "answers": [
                "10111010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "10111010"
            },
            {
              "id": "q5_11_tag",
              "label": "Tag in binary",
              "answers": [
                "1011"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1011"
            },
            {
              "id": "q5_11_idx",
              "label": "Set index in binary",
              "answers": [
                "101"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "101"
            },
            {
              "id": "q5_11_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_11_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r11_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r11_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r11_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r11_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r11_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r11_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0000"
              },
              {
                "id": "q5_r11_w1_1",
                "label": "Way 1 line 2",
                "answers": [
                  "T(101)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=1011"
              }
            ],
            [
              {
                "id": "q5_r11_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=0001"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0001"
              }
            ]
          ]
        },
        {
          "addr": "0x2e",
          "cells": [
            {
              "id": "q5_12_bin",
              "label": "Word address in binary",
              "answers": [
                "00101110"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "00101110"
            },
            {
              "id": "q5_12_tag",
              "label": "Tag in binary",
              "answers": [
                "0010"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0010"
            },
            {
              "id": "q5_12_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_12_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_12_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r12_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r12_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r12_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r12_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r12_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r12_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0010"
              },
              {
                "id": "q5_r12_w1_1",
                "label": "Way 1 line 2",
                "answers": [
                  "T(101)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=1011"
              }
            ],
            [
              {
                "id": "q5_r12_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=0001"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0001"
              }
            ]
          ]
        },
        {
          "addr": "0xce",
          "cells": [
            {
              "id": "q5_13_bin",
              "label": "Word address in binary",
              "answers": [
                "11001110"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "11001110"
            },
            {
              "id": "q5_13_tag",
              "label": "Tag in binary",
              "answers": [
                "1100"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "1100"
            },
            {
              "id": "q5_13_idx",
              "label": "Set index in binary",
              "answers": [
                "111"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "111"
            },
            {
              "id": "q5_13_off",
              "label": "Offset in binary",
              "answers": [
                "0"
              ],
              "type": "binary",
              "unit": "",
              "hint": "",
              "show": "0"
            },
            {
              "id": "q5_13_hm",
              "label": "Hit or Miss",
              "answers": [
                "M",
                "miss"
              ],
              "type": "text",
              "unit": "",
              "hint": "",
              "show": "M"
            },
            [
              {
                "id": "q5_r13_w0_0",
                "label": "Way 0 line 1",
                "answers": [
                  "T(001)=0000"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(001)=0000"
              },
              {
                "id": "q5_r13_w0_1",
                "label": "Way 0 line 2",
                "answers": [
                  "T(010)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(010)=1011"
              },
              {
                "id": "q5_r13_w0_2",
                "label": "Way 0 line 3",
                "answers": [
                  "T(101)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=0010"
              },
              {
                "id": "q5_r13_w0_3",
                "label": "Way 0 line 4",
                "answers": [
                  "T(111)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1011"
              },
              {
                "id": "q5_r13_w0_4",
                "label": "Way 0 line 5",
                "answers": [
                  "T(100)=0101"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(100)=0101"
              }
            ],
            [
              {
                "id": "q5_r13_w1_0",
                "label": "Way 1 line 1",
                "answers": [
                  "T(111)=0010"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=0010"
              },
              {
                "id": "q5_r13_w1_1",
                "label": "Way 1 line 2",
                "answers": [
                  "T(101)=1011"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(101)=1011"
              }
            ],
            [
              {
                "id": "q5_r13_w2_0",
                "label": "Way 2 line 1",
                "answers": [
                  "T(111)=1100"
                ],
                "type": "symbol",
                "unit": "",
                "hint": "",
                "show": "T(111)=1100"
              }
            ]
          ]
        }
      ],
      "fields_extra": [
        {
          "id": "q5_full",
          "label": "After these accesses, is the cache full?",
          "answers": [
            "no",
            "n",
            "không",
            "khong"
          ],
          "type": "text",
          "unit": "",
          "hint": "",
          "show": "no"
        },
        {
          "id": "q5_repl",
          "label": "How many replacements occurred?",
          "answers": [
            "2"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "2"
        }
      ],
      "solution": "Cache blocks = 48/2 = 24. Because this is 3-way, sets = 24/3 = 8, so index = 3 bits. Offset = log2(2) = 1 bit. Tag = 8 - 3 - 1 = 4 bits. Total bits = 24 × (2×64 data + 4 tag + 1 valid) = 3192 bits. Replacements occur only in set 111: 0x2e replaces T(111)=0000 in Các cột Way được giữ theo thứ tự block được đưa vào từng way vật lý; khi replacement xảy ra thì tag trong đúng way đó được thay, không sắp xếp lại theo set index."
    },
    {
      "id": "q6",
      "type": "datapath",
      "points": 10,
      "title": "Câu 6 - Single-cycle RISC-V datapath: sw",
      "image": "single_cycle_datapath",
      "prompt": "Consider a single-cycle RISC-V processor with the simple instruction set: <b>add, sub, and, or, lw, sw, beq</b>.<br><br>Let the processor execute the instruction:<br><code>sw x13, 160(x9)</code><br>at address <b>4096</b>. Suppose the initial value of register <code>xi</code> is <b>32i</b> for i = 1,...,31. Suppose the initial value of memory location with address M is <b>M + 500</b>.<br><br>Fill out the control signals and signals at locations A, B, C, ..., R.",
      "fields": [
        {
          "id": "q6_RegWrite",
          "label": "RegWrite",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q6_ALUSrc",
          "label": "ALUSrc",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q6_MemWrite",
          "label": "MemWrite",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q6_MemtoReg",
          "label": "MemtoReg",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q6_MemRead",
          "label": "MemRead",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q6_Branch",
          "label": "Branch",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q6_ALUOp",
          "label": "ALUOp",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q6_O",
          "label": "O",
          "answers": [
            "0010"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0010"
        },
        {
          "id": "q6_Zero",
          "label": "Zero",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q6_A",
          "label": "A",
          "answers": [
            "4096"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4096"
        },
        {
          "id": "q6_B",
          "label": "B",
          "answers": [
            "0x0AD4A023"
          ],
          "type": "hex",
          "unit": "",
          "hint": "",
          "show": "0x0AD4A023"
        },
        {
          "id": "q6_C",
          "label": "C",
          "answers": [
            "01001"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01001"
        },
        {
          "id": "q6_D",
          "label": "D",
          "answers": [
            "01101"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01101"
        },
        {
          "id": "q6_E",
          "label": "E",
          "answers": [
            "00000"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00000"
        },
        {
          "id": "q6_F",
          "label": "F",
          "answers": [
            "0100011"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0100011"
        },
        {
          "id": "q6_G",
          "label": "G",
          "answers": [
            "320"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "320"
        },
        {
          "id": "q6_H",
          "label": "H",
          "answers": [
            "4100"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4100"
        },
        {
          "id": "q6_I",
          "label": "I",
          "answers": [
            "288"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "288"
        },
        {
          "id": "q6_J",
          "label": "J",
          "answers": [
            "160"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "160"
        },
        {
          "id": "q6_K",
          "label": "K",
          "answers": [
            "448"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "448"
        },
        {
          "id": "q6_L",
          "label": "L",
          "answers": [
            "416"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "416"
        },
        {
          "id": "q6_M",
          "label": "M",
          "answers": [
            "?"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "?"
        },
        {
          "id": "q6_N",
          "label": "N",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q6_P",
          "label": "P",
          "answers": [
            "4096"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4096"
        },
        {
          "id": "q6_Q",
          "label": "Q",
          "answers": [
            "4100"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4100"
        },
        {
          "id": "q6_R",
          "label": "R",
          "answers": [
            "4416"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4416"
        }
      ],
      "solution": "For sw, RegWrite = 0, MemWrite = 1, MemRead = 0, ALUSrc = 1. rs1 = x9 = 288, rs2 = x13 = 416, imm = 160. Effective address = 288 + 160 = 448. The branch adder still computes PC + (imm << 1) = 4096 + 320 = 4416, even though Branch = 0."
    },
    {
      "id": "q7",
      "type": "datapath",
      "points": 10,
      "title": "Câu 7 - Single-cycle RISC-V datapath: lw",
      "image": "single_cycle_datapath",
      "prompt": "Consider the same single-cycle RISC-V processor.<br><br>Let the processor execute the instruction:<br><code>lw x18, 96(x11)</code><br>at address <b>4100</b>. Suppose the initial value of register <code>xi</code> is <b>32i</b> for i = 1,...,31. Suppose the initial value of memory location with address M is <b>M + 500</b>.",
      "fields": [
        {
          "id": "q7_RegWrite",
          "label": "RegWrite",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q7_ALUSrc",
          "label": "ALUSrc",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q7_MemWrite",
          "label": "MemWrite",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q7_MemtoReg",
          "label": "MemtoReg",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q7_MemRead",
          "label": "MemRead",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q7_Branch",
          "label": "Branch",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q7_ALUOp",
          "label": "ALUOp",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q7_O",
          "label": "O",
          "answers": [
            "0010"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0010"
        },
        {
          "id": "q7_Zero",
          "label": "Zero",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q7_A",
          "label": "A",
          "answers": [
            "4100"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4100"
        },
        {
          "id": "q7_B",
          "label": "B",
          "answers": [
            "0x0605A903"
          ],
          "type": "hex",
          "unit": "",
          "hint": "",
          "show": "0x0605A903"
        },
        {
          "id": "q7_C",
          "label": "C",
          "answers": [
            "01011"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01011"
        },
        {
          "id": "q7_D",
          "label": "D",
          "answers": [
            "00000"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00000"
        },
        {
          "id": "q7_E",
          "label": "E",
          "answers": [
            "10010"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "10010"
        },
        {
          "id": "q7_F",
          "label": "F",
          "answers": [
            "0000011"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0000011"
        },
        {
          "id": "q7_G",
          "label": "G",
          "answers": [
            "192"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "192"
        },
        {
          "id": "q7_H",
          "label": "H",
          "answers": [
            "4104"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4104"
        },
        {
          "id": "q7_I",
          "label": "I",
          "answers": [
            "352"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "352"
        },
        {
          "id": "q7_J",
          "label": "J",
          "answers": [
            "96"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "96"
        },
        {
          "id": "q7_K",
          "label": "K",
          "answers": [
            "448"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "448"
        },
        {
          "id": "q7_L",
          "label": "L",
          "answers": [
            "0"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q7_M",
          "label": "M",
          "answers": [
            "948"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "948"
        },
        {
          "id": "q7_N",
          "label": "N",
          "answers": [
            "948"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "948"
        },
        {
          "id": "q7_P",
          "label": "P",
          "answers": [
            "4100"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4100"
        },
        {
          "id": "q7_Q",
          "label": "Q",
          "answers": [
            "4104"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4104"
        },
        {
          "id": "q7_R",
          "label": "R",
          "answers": [
            "4292"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4292"
        }
      ],
      "solution": "lw x18, 96(x11): x11 = 32×11 = 352, effective address = 352 + 96 = 448, memory data = 448 + 500 = 948. Instruction = 0x0605A903. For I-type lw, bits [24:20] are imm[4:0], not rs2; 96 = 000001100000, so D = 00000 and the register file second read value L = x0 = 0. RegWrite=1, ALUSrc=1, MemRead=1, MemWrite=0, MemtoReg=1."
    },
    {
      "id": "q8",
      "type": "datapath",
      "points": 10,
      "title": "Câu 8 - Single-cycle RISC-V datapath: sub",
      "image": "single_cycle_datapath",
      "prompt": "Consider the same single-cycle RISC-V processor.<br><br>Let the processor execute the instruction:<br><code>sub x20, x12, x10</code><br>at address <b>4104</b>. Suppose the initial value of register <code>xi</code> is <b>32i</b> for i = 1,...,31. Suppose the initial value of memory location with address M is <b>M + 500</b>.",
      "fields": [
        {
          "id": "q8_RegWrite",
          "label": "RegWrite",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q8_ALUSrc",
          "label": "ALUSrc",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_MemWrite",
          "label": "MemWrite",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_MemtoReg",
          "label": "MemtoReg",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_MemRead",
          "label": "MemRead",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_Branch",
          "label": "Branch",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_ALUOp",
          "label": "ALUOp",
          "answers": [
            "10"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "10"
        },
        {
          "id": "q8_O",
          "label": "O",
          "answers": [
            "0110"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0110"
        },
        {
          "id": "q8_Zero",
          "label": "Zero",
          "answers": [
            "0"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_A",
          "label": "A",
          "answers": [
            "4104"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4104"
        },
        {
          "id": "q8_B",
          "label": "B",
          "answers": [
            "0x40A60A33"
          ],
          "type": "hex",
          "unit": "",
          "hint": "",
          "show": "0x40A60A33"
        },
        {
          "id": "q8_C",
          "label": "C",
          "answers": [
            "01100"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01100"
        },
        {
          "id": "q8_D",
          "label": "D",
          "answers": [
            "01010"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01010"
        },
        {
          "id": "q8_E",
          "label": "E",
          "answers": [
            "10100"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "10100"
        },
        {
          "id": "q8_F",
          "label": "F",
          "answers": [
            "0110011"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "0110011"
        },
        {
          "id": "q8_G",
          "label": "G",
          "answers": [
            "0"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "0"
        },
        {
          "id": "q8_H",
          "label": "H",
          "answers": [
            "4108"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4108"
        },
        {
          "id": "q8_I",
          "label": "I",
          "answers": [
            "384"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "384"
        },
        {
          "id": "q8_J",
          "label": "J",
          "answers": [
            "320"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "320"
        },
        {
          "id": "q8_K",
          "label": "K",
          "answers": [
            "64"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "64"
        },
        {
          "id": "q8_L",
          "label": "L",
          "answers": [
            "320"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "320"
        },
        {
          "id": "q8_M",
          "label": "M",
          "answers": [
            "?"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "?"
        },
        {
          "id": "q8_N",
          "label": "N",
          "answers": [
            "64"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "64"
        },
        {
          "id": "q8_P",
          "label": "P",
          "answers": [
            "4104"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4104"
        },
        {
          "id": "q8_Q",
          "label": "Q",
          "answers": [
            "4108"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4108"
        },
        {
          "id": "q8_R",
          "label": "R",
          "answers": [
            "4104"
          ],
          "type": "decimal",
          "unit": "",
          "hint": "",
          "show": "4104"
        }
      ],
      "solution": "For sub, ALUSrc = 0, MemtoReg = 0, RegWrite = 1, ALUOp = 10, and ALU control O = 0110. x12 = 384 and x10 = 320, so the ALU result is 64. Data memory is not read, so M is unknown (?) and N = 64."
    },
    {
      "id": "q9",
      "type": "pipeline",
      "points": 10,
      "title": "Câu 9 - 5-stage pipeline with forwarding and hazard detection",
      "image": "pipeline_datapath",
      "prompt": "Assume that the following code sequence is executed on the 5-stage pipelined processor with forwarding and hazard detection units shown below:<br><pre>add x6, x1, x2\nlw  x7, 4(x6)\nlw  x8, 0(x6)\nor  x7, x6, x7\nsw  x7, 0(x6)</pre>For the first seven cycles, specify the values of control signals at A, B, C, D, E, F, and G.",
      "pipe_rows": [
        "1st",
        "2nd",
        "3rd",
        "4th",
        "5th",
        "6th",
        "7th"
      ],
      "fields": [
        {
          "id": "q9_r0_A",
          "label": "1st - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r0_B",
          "label": "1st - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r0_C",
          "label": "1st - C",
          "answers": [
            "xx"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "xx"
        },
        {
          "id": "q9_r0_D",
          "label": "1st - D",
          "answers": [
            "xx"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "xx"
        },
        {
          "id": "q9_r0_E",
          "label": "1st - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r0_F",
          "label": "1st - F",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r0_G",
          "label": "1st - G",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r1_A",
          "label": "2nd - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r1_B",
          "label": "2nd - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r1_C",
          "label": "2nd - C",
          "answers": [
            "xx"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "xx"
        },
        {
          "id": "q9_r1_D",
          "label": "2nd - D",
          "answers": [
            "xx"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "xx"
        },
        {
          "id": "q9_r1_E",
          "label": "2nd - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r1_F",
          "label": "2nd - F",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r1_G",
          "label": "2nd - G",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r2_A",
          "label": "3rd - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r2_B",
          "label": "3rd - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r2_C",
          "label": "3rd - C",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r2_D",
          "label": "3rd - D",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r2_E",
          "label": "3rd - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r2_F",
          "label": "3rd - F",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r2_G",
          "label": "3rd - G",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r3_A",
          "label": "4th - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r3_B",
          "label": "4th - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r3_C",
          "label": "4th - C",
          "answers": [
            "10"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "10"
        },
        {
          "id": "q9_r3_D",
          "label": "4th - D",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r3_E",
          "label": "4th - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r3_F",
          "label": "4th - F",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r3_G",
          "label": "4th - G",
          "answers": [
            "x"
          ],
          "type": "symbol",
          "unit": "",
          "hint": "",
          "show": "x"
        },
        {
          "id": "q9_r4_A",
          "label": "5th - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r4_B",
          "label": "5th - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r4_C",
          "label": "5th - C",
          "answers": [
            "01"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01"
        },
        {
          "id": "q9_r4_D",
          "label": "5th - D",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r4_E",
          "label": "5th - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r4_F",
          "label": "5th - F",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r4_G",
          "label": "5th - G",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r5_A",
          "label": "6th - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r5_B",
          "label": "6th - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r5_C",
          "label": "6th - C",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r5_D",
          "label": "6th - D",
          "answers": [
            "01"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "01"
        },
        {
          "id": "q9_r5_E",
          "label": "6th - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r5_F",
          "label": "6th - F",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r5_G",
          "label": "6th - G",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r6_A",
          "label": "7th - A",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r6_B",
          "label": "7th - B",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r6_C",
          "label": "7th - C",
          "answers": [
            "00"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "00"
        },
        {
          "id": "q9_r6_D",
          "label": "7th - D",
          "answers": [
            "10"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "10"
        },
        {
          "id": "q9_r6_E",
          "label": "7th - E",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r6_F",
          "label": "7th - F",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q9_r6_G",
          "label": "7th - G",
          "answers": [
            "1"
          ],
          "type": "binary",
          "unit": "",
          "hint": "",
          "show": "1"
        }
      ],
      "solution": "This sequence has the same dependency pattern as the standard exercise. Correct rows: 1st/2nd = 1 1 xx xx 1 x x; 3rd = 1 1 00 00 1 x x; 4th = 1 1 10 00 1 1 x; 5th = 1 1 01 00 1 1 1; 6th = 1 1 00 01 1 1 1; 7th = 1 1 00 10 1 1 1."
    },
    {
      "id": "q10",
      "type": "fields",
      "points": 10,
      "title": "Câu 10 - Execution time: single-cycle vs pipeline",
      "prompt": "Consider the following sequence of 32-bit RISC-V instructions:<br><pre>add x8,  x1,  x2\nlw  x9,  0(x8)\nadd x10, x9,  x3\nsub x11, x10, x8\nsw  x11, 4(x8)</pre>a) Single-cycle processor clock cycle time = <b>1000 ps</b>.<br>b) 5-stage pipelined processor clock cycle time = <b>250 ps</b>, without forwarding or hazard detection units. Insert NOPs to ensure correct execution.<br>c) 5-stage pipelined processor clock cycle time = <b>250 ps</b>, with forwarding/hazard detection units.<br>d) Which case gives the medium performance?",
      "fields": [
        {
          "id": "q10_a",
          "label": "a) Execution time on single-cycle processor",
          "answers": [
            "5000"
          ],
          "type": "decimal",
          "unit": "ps",
          "hint": "",
          "show": "5000"
        },
        {
          "id": "q10_b_nop",
          "label": "b) Number of inserted NOPs",
          "answers": [
            "8"
          ],
          "type": "decimal",
          "unit": "NOPs",
          "hint": "",
          "show": "8"
        },
        {
          "id": "q10_b_cycles",
          "label": "b) Number of cycles after inserting NOPs",
          "answers": [
            "17"
          ],
          "type": "decimal",
          "unit": "cycles",
          "hint": "",
          "show": "17"
        },
        {
          "id": "q10_b_time",
          "label": "b) Execution time without forwarding/hazard detection",
          "answers": [
            "4250"
          ],
          "type": "decimal",
          "unit": "ps",
          "hint": "",
          "show": "4250"
        },
        {
          "id": "q10_c_stall",
          "label": "c) Number of stalls/NOPs needed with forwarding/hazard detection",
          "answers": [
            "1"
          ],
          "type": "decimal",
          "unit": "stall",
          "hint": "",
          "show": "1"
        },
        {
          "id": "q10_c_cycles",
          "label": "c) Number of cycles",
          "answers": [
            "10"
          ],
          "type": "decimal",
          "unit": "cycles",
          "hint": "",
          "show": "10"
        },
        {
          "id": "q10_c_time",
          "label": "c) Execution time with forwarding/hazard detection",
          "answers": [
            "2500"
          ],
          "type": "decimal",
          "unit": "ps",
          "hint": "",
          "show": "2500"
        },
        {
          "id": "q10_d",
          "label": "d) Medium performance case",
          "answers": [
            "b",
            "case b",
            "b)"
          ],
          "type": "text",
          "unit": "",
          "hint": "",
          "show": "b"
        }
      ],
      "solution": "Single-cycle: 5 × 1000 = 5000 ps. Without forwarding/hazard detection, dependencies add→lw, lw→add, add→sub, and sub→sw each need 2 NOPs, so 8 NOPs total. There are 13 instructions including NOPs, so pipeline cycles = 13 + 4 = 17 and time = 4250 ps. With forwarding/hazard detection, only the adjacent load-use lw x9 → add x10 needs 1 stall, so cycles = 5 + 4 + 1 = 10 and time = 2500 ps. Medium performance is case b."
    }
  ]
});
